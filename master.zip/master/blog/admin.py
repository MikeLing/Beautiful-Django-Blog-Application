from django.contrib import admin
from blog.models import Post
#from blog.models import Slider1, Slider2, Slider3, Comment, Moto

admin.site.register(Post)

